
-----------SILKE ROSENA SOUNDSET FOR BG2EE & EET-----------
----------------------WITH SUBTITLES-----------------------

Version: 1.0     Platform: BG2EE & EET     Mod Author: Wres



--DESCRIPTION--

Have you ever wanted Silke Rosena to join your party instead of having to kill her? Or worse, watch her run off into the inn and pull a disappearing act? Me, too. Until I get around to finishing that mod, here is a soundset based (mostly) on the vanilla Silke NPC. It's a little limited, to be honest, but it works. Best suited for bards, mages or fighters, as it doesn't have any sounds for thieving skills (except Pick Pocket).


--INSTALLATION--

Unpack the contents of the zip file into your BG2EE/EET directory and run Setup-Silke.exe to install.

Please note: This version will not work for BGEE. For that type of installation, download the BGEE version instead.


--CREDITS--

Mod author: Wres

Thanks to Smeagolheart for the wonderful Soundset Mod Shell that let me figure out how to use subtitles for my soundsets.
NearInfinity for allowing me to dig through the game files, which is always fun. You never know what you might find...
This is a non-profit fancreation for private use only.