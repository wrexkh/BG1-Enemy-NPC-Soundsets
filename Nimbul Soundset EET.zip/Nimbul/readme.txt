
--------------NIMBUL SOUNDSET FOR BG2EE & EET--------------
-----------------------WITH SUBTITLES----------------------

Version: 1.0     Platform: BG2EE & EET     Mod Author: Wres



--DESCRIPTION--

It's a shame you have to kill Nimbul, isn't it? At least now you can have his voice. I used NearInfinity to dig up some voice lines and turned them into a soundset. Best suited for pretty much everyone. There aren't that many sounds.


--INSTALLATION--

Unpack the contents of the zip file into your BG2EE directory and run Setup-Nimble.exe to install.

Please note: This version will not work for BGEE. For that type of installation, download the BGEE version instead.


--CREDITS--

Mod author: Wres

Thanks to Smeagolheart for the wonderful Soundset Mod Shell that let me figure out how to use subtitles for my soundsets.
NearInfinity for allowing me to dig through the game files, which is always fun. You never know what you might find...
This is a non-profit fancreation for private use only.