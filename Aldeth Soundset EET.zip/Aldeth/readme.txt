
---------ALDETH SASHENSTAR SOUNDSET FOR BG2EE & EET--------
----------------------WITH SUBTITLES-----------------------

Version: 1.0     Platform: BG2EE & EET     Mod Author: Wres



--DESCRIPTION--

I found some unused soundfiles (at least I've never heard them) for Aldeth Sashenstar and decided to put them together as a soundset. You remember that prick in the Cloakwood Forest? The one who wants you to murder a bunch of druids? Well, now you can sound just like him. Lucky you!

Best suited for fighters, clerics, and mages, as it doesn't have any sounds for thieving skills.


--INSTALLATION--

Unpack the contents of the zip file into your BG2EE/EET directory and run Setup-Aldeth.exe to install.

Please note: This version will not work for BGEE. For that type of installation, download the BGEE version instead.


--CREDITS--

Mod author: Wres

Thanks to Smeagolheart for the wonderful Soundset Mod Shell that let me figure out how to use subtitles for my soundsets.
NearInfinity for allowing me to dig through the game files, which is always fun. You never know what you might find...
This is a non-profit fancreation for private use only.