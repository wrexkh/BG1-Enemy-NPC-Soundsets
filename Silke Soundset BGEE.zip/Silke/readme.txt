
-----------SILKE ROSENA SOUNDSET FOR BGEE-----------
-------------------WITH SUBTITLES-------------------

Version: 1.0     Platform: BGEE     Mod Author: Wres



--DESCRIPTION--

Have you ever wanted Silke Rosena to join your party instead of having to kill her? Or worse, watch her run off into the inn and pull a disappearing act? Me, too. Until I get around to finishing that mod, here is a soundset based on the vanilla NPC in Beregost. It's a little limited to be honest, but it works. Best suited for bards, mages or fighters, as it doesn't have any sounds for thieving skills (except Pick Pocket).


--INSTALLATION--

Unpack the contents of the zip file into your BGEE directory and run Setup-Silke.exe to install.

In order to make this soundset work (with no mismatched sounds and subtitles) on a BGEE installation, and where you have used modmerge to prepare the game for modding, you MUST first copy 'CHARSND.2da' into your 'override' folder before installing.

File and instructions can be found here: https://forums.beamdog.com/discussion/73279/a-solution-for-the-sound-mods-in-siege-of-dragonspear


--CREDITS--

Mod author: Wres

Thanks to Smeagolheart for the wonderful Soundset Mod Shell that let me figure out how to use subtitles for my soundsets.
NearInfinity for allowing me to dig through the game files, which is always fun. You never know what you might find...
This is a non-profit fancreation for private use only.