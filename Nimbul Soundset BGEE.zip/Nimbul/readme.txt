
--------------NIMBUL SOUNDSET FOR BGEE--------------
-------------------WITH SUBTITLES-------------------

Version: 1.0     Platform: BGEE     Mod Author: Wres



--DESCRIPTION--

It's a shame you have to kill Nimbul, isn't it? At least now you can have his voice. I used NearInfinity to dig up some voice lines and turned them into a soundset. Best suited for pretty much everyone. There's not that many sounds.


--INSTALLATION--

Unpack the contents of the zip file into your BGEE directory and run Setup-Nimble.exe to install.

In order to make this soundset work (with no mismatched sounds and subtitles) on a BGEE installation, and where you have used modmerge to prepare the game for modding, you MUST first copy 'CHARSND.2da' into your 'override' folder before installing.

File and instructions can be found here: https://forums.beamdog.com/discussion/73279/a-solution-for-the-sound-mods-in-siege-of-dragonspear


--CREDITS--

Mod author: Wres

Thanks to Smeagolheart for the wonderful Soundset Mod Shell that let me figure out how to use subtitles for my soundsets.
NearInfinity for allowing me to dig through the game files, which is always fun. You never know what you might find...
This is a non-profit fancreation for private use only.